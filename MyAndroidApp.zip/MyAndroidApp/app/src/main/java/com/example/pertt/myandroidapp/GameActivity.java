package com.example.pertt.myandroidapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by pertt on 2017-12-12.
 */

public class GameActivity extends Activity {
    @Override
    public void onCreate(Bundle bundleInstance) {
        super.onCreate(bundleInstance);
        setContentView(R.layout.game_activity);
    }
    public void onGuessClick(View v) {
        Button b = (Button) v;
        String letter = b.getText();
    }
}
